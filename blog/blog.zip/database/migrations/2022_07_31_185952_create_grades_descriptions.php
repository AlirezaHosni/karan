<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateGradesDescriptions extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('grades_descriptions', function (Blueprint $table) {
            $table->id();
            $table->text("description")->nullable();
            $table->unsignedBigInteger("grade_id")->nullable();
            $table->text("image")->nullable();
            $table->text("descriptionTwo")->nullable();
            $table->text("imageTwo")->nullable();
            // $table->text("menu")->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('grades_descriptions');
    }
}
