<div class="main-footer text-center">
    <div class="container">
        <div class="row row-sm">
            <div class="col-md-12">
                <p> Copyright 2019 - All Rights Reserved by ... </p>
            </div>
        </div>
    </div>
</div>
