
<!-- Loader -->
<div id="global-loader">
    <img src="{{asset('backEnd/img/loader.svg')}}" class="loader-img" alt="لودر" />
</div>
<!-- End Loader -->
