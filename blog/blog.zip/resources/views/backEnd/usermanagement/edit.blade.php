@extends('backEnd.layouts.master')
@section('master')
    <!-- Main Content-->
    <div class="main-content side-content pt-0">
        <div >
            <div class="inner-body">
                <!-- Row -->
                <div class=" square mt-5">
                    <div class="col-lg-12">
                        <div class="card custom-card ">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-sm-6 col-md-4 col-xl-4 p-1">
                                        <div class="card custom-card">
                                            <div class="user-card text-center">
                                                <div class="  online text-center ">
                                                    <img alt="" class="rounded-circle edituser-img" src="{{asset('upload/user/'.$user->image)}}">
                                                </div>
                                                <div class="mt-2">
                                                    <form action="{{route('UploadImage',$user->id)}}" method="post" enctype="multipart/form-data">
                                                        @csrf
                                                    <button type="submit" class="btn btn-warning my-3 py-2 px-4">تغییر عکس</button>

                                                    <div class="input-group mb-3">
                                                        <input type="file" name="image" class="form-control" id="inputGroupFile01">
                                                        <hr>
                                                    </div>
                                                    </form>

                                                    <div class="d-flex justify-content-between mt-3">
                                                        <p>نام و نام خانوادگی: </p>
                                                        <p>{{$user->name}}</p>
                                                    </div>
                                                    <div class="d-flex justify-content-between mt-3">
                                                        <p>نام و نام خانوادگی: </p>
                                                        <p>{{$user->fullName}}</p>
                                                    </div>
                                                    <div class="d-flex justify-content-between">
                                                        <p> موبایل: </p>
                                                        <p> {{$user->phoneNumber}}</p>
                                                    </div>
                                                    <div class="d-flex justify-content-between">
                                                        <p>نقش شما:</p>
                                                        <p> {{implode(',',$user->roles()->get()->pluck('name')->toArray())}} </p>
                                                    </div>
                                                    <div class="d-flex justify-content-between">
                                                        <p> ایمیل:</p>
                                                        <p>{{$user->email}}</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-8 col-md-8">
                                        <div class="profile-tab tab-menu-heading">
                                            <nav class="nav main-nav-line p-3 active tabs-menu profile-nav-line bg-gray-100">
                                                ویرایش اطلاعات
                                            </nav>
                                        </div>
                                        <div class="card custom-card main-content-body-profile">
                                            <div class="tab-content">

                                                        <div class="border-top"></div>
                                                        <div class="border-top"></div>
                                                    </div>
                                                </div>
                                                <div class="main-content-body tab-pane p-4 border-top-0" >
                                                    <div class="card-body border">
                                                        <div class="mb-4 main-content-label">اطلاعات کاربر</div>
                                                        <form class="form-horizontal" action="{{route('userManagement.update',$user->id)}}" method="post">
                                                            @csrf
                                                            @method('put')
                                                            <div class="mb-4 main-content-label"></div>
                                                            <div class="form-group ">
                                                                <div class="row row-sm">
                                                                    <div class="col-md-3">
                                                                        <label class="form-label">نام کاربری</label>
                                                                    </div>
                                                                    <div class="col-md-9">
                                                                        <input type="text" name="name" class="form-control" placeholder="نام کاربری" value="{{$user->name}}">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="form-group ">
                                                                <div class="row row-sm">
                                                                    <div class="col-md-3">
                                                                        <label class="form-label">نام و نام خانوادگی </label>
                                                                    </div>
                                                                    <div class="col-md-9">
                                                                        <input type="text" name="fullName" class="form-control" placeholder="نام کوچک" value="{{$user->fullName}}">
                                                                    </div>
                                                                </div>
                                                            </div>


                                                            <div class="form-group ">
                                                                <div class="row row-sm">
                                                                    <div class="col-md-3">
                                                                        <label class="form-label">ایمیل
                                                                        </label>
                                                                    </div>
                                                                    <div class="col-md-9">
                                                                        <input type="text" name="email" class="form-control" placeholder="پست الکترونیک" value="{{$user->email}}">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="form-group ">
                                                                <div class="row row-sm">
                                                                    <div class="col-md-3">
                                                                        <label class="form-label"> شماره همراه</label>
                                                                    </div>
                                                                    <div class="col-md-9">
                                                                        <input type="text" name="phoneNumber" class="form-control" placeholder=" شماره همراه " value="{{$user->phoneNumber}}">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="form-group ">
                                                                <div class="row row-sm">
                                                                    <div class="col-md-3">
                                                                        <label class="form-label"> تعیین نقش</label>
                                                                    </div>
                                                                    <div class="col-md-9">
                                                                        <select name="role_id" id="role" class="form-control">
                                                                            @foreach($roles as $role)
                                                                                <option value="{{$role->id}}">{{$role->name}}</option>
                                                                            @endforeach
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="mt-3">
                                                                <button  type="submit" class="btn btn-warning mr-1">ذخیره کردن </button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>

                            <!-- Row -->

                        </div>

                    </div>
@endsection
