@extends('backEnd.layouts.master')
@section('master')
    <!-- Main Content-->
    <div class="main-content side-content pt-0">
        <div class="container-fluid">
            <div class="inner-body">
                <!--Row-->
                <div class="row row-sm mt-2">
                    <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 grid-margin">
                        <div class="card custom-card pt-2">
                            <div class="card-header border-bottom-0 pb-0">
                                <div class="d-flex justify-content-center">
                                    <h3 class="font-weight-bold">معرفی کتاب</h3>
                                </div>
                            </div>
                            <hr>
                            <form action="#" method="post" class=" d-flex justify-content-center" enctype="multipart/form-data">
                                @csrf
                                <div class="col-12">
                                    <div class="row-cols-2 row">
                                        <div class="form-group col-6">
                                            <label for="grade_id">پایه مورد نظر را انتخاب کنید:</label>
                                            <select name="grade_id"  class="form-control" id="gradeOptions" data-url="{{ route('searchLessons') }}">
                                                @foreach($grades as $grade)
                                                    <option value="{{$grade->id}}" @if(old('grade_id') == $grade->id) selected @endif>{{$grade->title}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <div class="form-group col-6">
                                            <label for="lesson_id">کتاب مورد نظر را انتخاب کنید:</label>
                                            <select name="lesson_id" class="form-control" id="lessonOptions" data-url="{{ route('searchSessions') }}">
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <div class="card-header border-bottom-0 pb-0">
                                <div class="card-body">
                                    <ul class="list-group list-group-horizontal col-12 w-100">
                                        <li class="list-group-item col-3">
                                            <a class="page-link py-10" href="#">بیوگرافی و فلسفه کتاب</a>
                                        </li>
                                        <li class="list-group-item col-3">
                                            <a class="page-link py-10 " href="#"> کتاب در کنکور</a>
                                        </li>
                                        <li class="list-group-item col-3 ">
                                            <a class="page-link py-10" href="#">کتاب در امتحان پایانی </a>
                                        </li>
                                        <li class="list-group-item col-3">
                                            <a class="page-link py-10" href="#">نحوه مطالعه کتاب</a>
                                        </li>
                                    </ul>
                                </div>
                                <hr>
                            </div>
                            <form action="{{route('education.IntroduceBookAttachmentsStore')}}" method="post" class=" d-flex justify-content-center" id="form" enctype="multipart/form-data">
                                @csrf
                                <div class="row col-12">
                                    <div class="col-12 row h-auto">
                                        <div id="attachmentDiv" class="col-12">
                                            <div class="form-group col-6">
                                                <label for="">بارگزاری ویدیو/جزوه:</label>
                                                <input type="file" name="attachments[]" class="form-control" />
                                                <input type="hidden" name="lesson_id" id="selected_lesson_id" class="form-control" />
                                            </div>
                                        </div>
                                    </div>
                                        <div class="form-group row mr-2 col-6">
                                            <button type="button" class="btn btn-info ml-2 createAttachment">
                                                ویدیو/جزوه جدید
                                            </button>
                                            <button type="reset" class="btn btn-info ml-2">
                                                جدید
                                            </button>
                                            <button type="submit" class="btn btn-info">
                                                ثبت
                                            </button>
                                        </div>
                                </div>
                            </form>
                            <div class="card-body">
                                <div class="table-responsive border userlist-table">
                                    <table class="table card-table table-striped table-vcenter text-nowrap mb-0">
                                        <thead>
                                        <tr>
                                            <th class="wd-lg-8p"><span> ردیف</span></th>
                                            <th class="wd-lg-8p"><span> نوع</span></th>
                                            <th class="wd-lg-20p"><span>کتاب</span></th>
                                            <th class="wd-lg-20p text-center">عمل</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @php
                                            $key=0;
                                        @endphp
                                        @foreach($videos as $video)
                                            <tr>
                                                <td>{{++$key}}</td>
                                                <td>ویدیو</td>
                                                <td>{{ $video->videoable->title }}</td>
                                                <td class="d-flex justify-content-center">
                                                    <a href="{{route('video.edit',$video->id)}}" class="btn btn-success btn-sm ml-2">
                                                        <i class="fe fe-edit-2"></i>
                                                    </a>
                                                    <form action="{{route('video.destroy',$video->id)}}" method="post">
                                                        @csrf
                                                        @method('delete')
                                                        <button class="btn btn-danger btn-sm" type="submit">
                                                            <i class="fe fe-trash"></i>
                                                        </button>
                                                    </form>
                                                </td>
                                                @endforeach
                                        @foreach($documents as $document)
                                            <tr>
                                                <td>{{++$key}}</td>
                                                <td>جزوه</td>
                                                <td>{{ $document->documentable->title }}</td>
                                                <td class="d-flex justify-content-center">
                                                    <a href="{{route('document.edit',$document->id)}}" class="btn btn-success btn-sm ml-2">
                                                        <i class="fe fe-edit-2"></i>
                                                    </a>
                                                    <form action="{{route('document.destroy',$document->id)}}" method="post">
                                                        @csrf
                                                        @method('delete')
                                                        <button class="btn btn-danger btn-sm" type="submit">
                                                            <i class="fe fe-trash"></i>
                                                        </button>
                                                    </form>
                                                </td>
                                                @endforeach
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
{{--                                <ul class="pagination mt-4 mb-0 float-left">--}}
{{--                                    <li class="page-item page-prev disabled">--}}
{{--                                        <a class="page-link" href="#" tabindex="-1">قبلی</a>--}}
{{--                                    </li>--}}
{{--                                    <li class="page-item active"><a class="page-link" href="#">1</a></li>--}}
{{--                                    <li class="page-item"><a class="page-link" href="#">2</a></li>--}}
{{--                                    <li class="page-item"><a class="page-link" href="#">3</a></li>--}}
{{--                                    <li class="page-item"><a class="page-link" href="#">4</a></li>--}}
{{--                                    <li class="page-item"><a class="page-link" href="#">5</a></li>--}}
{{--                                    <li class="page-item page-next">--}}
{{--                                        <a class="page-link" href="#">بعد</a>--}}
{{--                                    </li>--}}
{{--                                </ul>--}}
                            </div>
                        </div>
                    </div>
                    <!-- COL END -->
                </div>
                <!-- row closed  -->
            </div>
        </div>
    </div>
    <!-- End Main Content-->
@endsection
@section('js')
    <script>
        $(document).ready(function () {
            $('.createAttachment').click(function () {
                $('#attachmentDiv').append(`<div class="form-group col-6">
                                            <label for="">بارگزاری ویدیو/جزوه:</label>
                                            <input type="file" name="attachments[]" class="form-control" />
                                        </div>`)
            });
        });
        $('#form').submit(function (){
            var topicSelected = $('#lessonOptions').val()
            var topicInput = $('#selected_lesson_id')
            topicInput.val(topicSelected)
        });
    </script>
@endsection
