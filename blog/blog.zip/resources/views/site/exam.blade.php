<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="{{asset('site/css/bootstrap.rtl.min.css')}}">


    <link rel="stylesheet" href="{{asset('site/css/style.css')}}">
    <title>نکته و تست</title>
</head>

<body>
<!-- sectionOne -->
<section class="section-one mt-5">
    <nav class="navbar navbar-expand-lg navbar-light bg-light p-3 container  ">
        <div class="container-fluid">
            <div class="row w-100">
                <div class="signin-users">
                    <a class="nav-link login-users navbar-links mx-1 text-black " aria-current="page" href="#"> <img
                            src="{{asset('site/images/users.png')}}"
                            height="25px" class="mx-1" alt=""> ورود کاربران</a>
                </div>

                <div class="header-brand">
                    <span></span>
                </div>
            </div>

        </div>
    </nav>
</section>

<!-- end sectionOne -->
<!-- sectionTWO -->
<section>
    <div class="container col-xl-12 p-3  section-two mt-2 ">

        <form action="{{route('exam.view',['bookid'=>$bookid])}}">
            <div class="row">
                <div class="container-fluid">
                    <p>لطفا نوع و سطح آزمون خود را انتخاب کنید</p>
                </div>
                <div class="col-xl-10 row">
                    <div class="col-xl-5 col-md test-row1 p-3   d-flex mx-2 pt-3 @if(!isset($examBook)) h-50 @endif">
                        <div class="form-check">
                            <input required checked
                                   class="form-check-input testi-input" type="radio" value="test"
                                   name="type"
                                   id="flexRadioDefault1">


                        </div>
                        <div class="mx-2">
                            <p>تستی </p>

                            <div class="d-flex">
                                <div class="form-check radio1">
                                    <input required
                                           @if(isset($level) && $level == 1)
                                           checked
                                           @endif
                                           type="radio" class="form-check-input " id="radio1" name="level"
                                           value="1"> ساده
                                    <label class="form-check-label" for="radio1"></label>
                                </div>
                                <div class="form-check radio2">
                                    <input
                                        @if(isset($level) && $level == 2)
                                        checked
                                        @endif
                                        required type="radio" class="form-check-input" id="radio2" name="level"
                                        value="2"> متوسط
                                    <label class="form-check-label" for="radio2"></label>
                                </div>
                                <div class="form-check radio3">
                                    <input
                                        @if(isset($level) && $level == 3)
                                        checked
                                        @endif
                                        required type="radio" class="form-check-input" id="radio3" name="level"
                                        value="3"> سخت
                                    <label class="form-check-label" for="radio3"></label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6 col-md test-row1 p-3  d-flex mx-2 pt-3 @if(!isset($examBook)) h-50 @endif">
                        <div class="form-check">
                            <input required class="form-check-input tashrihi-input  " value="tashrih" type="radio"
                                   name="type"
                                   id="flexRadioDefault2">

                        </div>
                        <div class="mx-2">
                            <p> تشریحی</p>

                            <div class="d-flex">
                                <div class="form-check radio4">
                                    <input type="radio" class="form-check-input " id="radio4" name="optradio"
                                           value="option4"> ساده
                                    <label class="form-check-label" for="radio4"></label>
                                </div>
                                <div class="form-check radio5">
                                    <input type="radio" class="form-check-input" id="radio5" name="optradio"
                                           value="option5"> متوسط
                                    <label class="form-check-label" for="radio5"></label>
                                </div>
                                <div class="form-check radio6">
                                    <input type="radio" class="form-check-input" id="radio6" name="optradio"
                                           value="option6"> سخت
                                    <label class="form-check-label" for="radio6"></label>
                                </div>
                            </div>
                        </div>
                    </div>

                    @if(!isset($examBook))
                        <div class="container">
                            <div class="text-center">
                                <button type="submit" class="btn btn-outline-success">
                                    مشاهده آزمون
                                </button>
                            </div>
                        </div>

                    @endif

                    @if(isset($examBook))
                        <div class="container col-xl-11 p-3 bg-light slider-row">
                            <div class="row mt-5">
                                @if($examBook->count() > 0)
                                    <div class="scroller">

                                        @foreach($examBook as $question)
                                            <div class="d-flex p-2 @if(!$loop->first) mt-5 @endif">
                                                <p class="mx-2">{{$loop->iteration}}</p>
                                                <p>{{$question->question}}</p>
                                            </div>
                                            <div class="d-flex justify-content-between p-2">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio" name="exRadios{{$question->id}}"
                                                           id="exRadios{{$question->id}}"
                                                           value="option1">
                                                    <label class="form-check-label" for="exRadios{{$question->id}}">
                                                        {{$question->answerOne}}
                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio" name="exRadios{{$question->id}}"
                                                           id="exRadios2"
                                                           value="option{{$question->id}}">
                                                    <label class="form-check-label" for="exRadios{{$question->id}}">
                                                        {{$question->answerTwo}}
                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio" name="exRadios{{$question->id}}"
                                                           id="exRadios{{$question->id}}"
                                                           value="option1">
                                                    <label class="form-check-label" for="exRadios{{$question->id}}">
                                                        {{$question->answerThree}}
                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio" name="exRadios{{$question->id}}"
                                                           id="exRadios{{$question->id}}"
                                                           value="option2">
                                                    <label class="form-check-label" for="exRadios{{$question->id}}">
                                                        {{$question->answerFour}}
                                                    </label>
                                                </div>

                                            </div>

                                        @endforeach


                                    </div>
                                @else
                                    <div class="text-center">
                                        آزمونی یافت نشد
                                    </div>
                                @endif

                            </div>
                        </div>
                        <div class="container mt-3 mb-2">
                            <div class="text-center">
                                <button type="submit" class="btn btn-outline-success">
                                    بارگذاری مجدد آزمون
                                </button>
                            </div>
                        </div>

                    @endif


                </div>

                <div class="col-xl-2  sidebar-left py-5 text-center">
                    <img src="{{asset('site/images/hand-arrow-down.png')}}" class="mb-3 icon-sidebar-left " height="50"
                         alt="">
                    <p class="text-light title-sidebar ">دسترسی آسان</p>
                    <nav class="nav flex-column sidebar-nav">
                        <a class="nav-link text-light sidebar-links active" href="#"> معرفی کتاب</a>
                        <a class="nav-link text-light sidebar-links" href="#"> درسنامه تشریحی</a>
                        <a class="nav-link text-light sidebar-links" href="#"> سوالات تشریحی </a>
                        <a class="nav-link text-light sidebar-links active-link-sidebar" href="#"> نکته و تست</a>
                        <a class="nav-link text-light sidebar-links" href="#"> ضمایم</a>
                        <a class="nav-link text-light sidebar-links" href="#"> آزمون انتخابی</a>
                        <a class="nav-link text-light sidebar-links" href="#"> کران بالا</a>
                        <a class="nav-link text-light sidebar-links" href="#"> نمونه سوالات امتحانی</a>
                        <a class="nav-link text-light sidebar-links" href="#"> تست های جامع</a>
                        <a class="nav-link text-light sidebar-links" href="#"> تمارین داخل کتاب</a>

                    </nav>
                </div>

            </div>

        </form>


    </div>

</section>
<!-- end sectionTWO -->
<script src="{{asset('site/js/bootstrap.min.js')}}"></script>
<script src="{{asset('site/js/app.js')}}"></script>


</body>

</html>
