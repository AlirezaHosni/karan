<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="{{asset('site/css/bootstrap.rtl.min.css')}}">


    <link rel="stylesheet" href="{{asset('site/css/style.css')}}">
    <title>معرفی کتاب</title>
</head>

<body>
<!-- sectionOne -->
<section class="section-one mt-5">
    <nav class="navbar navbar-expand-lg navbar-light bg-light p-3 container  ">
        <div class="container-fluid">
            <div class="row w-100">
                <div class="signin-users">
                    <a class="nav-link login-users navbar-links mx-1 text-black " aria-current="page"
                       href="{{route('login')}}"> <img
                            src="{{asset('site/images/users.png')}}"
                            height="25px" class="mx-1" alt=""> ورود کاربران</a>
                </div>

                <div class="header-brand">
                    <span></span>
                </div>
            </div>

        </div>
    </nav>
</section>
<!-- end sectionOne -->
<!-- sectionTWO -->
<section class="mt-5">
    <div class="container bg-light p-5 category">
        <div class="accordion category-section" id="accordionPanelsStayOpenExample">
            <!-- item 1 -->
                <div class="accordion-item">
                    <h2 class="accordion-header" id="panelsStayOpen-h0">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                data-bs-target="#panelsStayOpen-c0" aria-expanded="true"
                                aria-controls="panelsStayOpen-c0">
                            {{ $books->first()->session }}
                        </button>
                    </h2>
                    <div id="panelsStayOpen-c0"
                         class="accordion-collapse show"
                         aria-labelledby="panelsStayOpen-h0">
                        <ul class="subcategory">
                            @foreach($books as $book)
                                <li>
                                    <a href="{{ session()->has('operation') ? session()->get('operation') == 'test' ? route('exam',$book->id) : route('overview.' . session()->get('operation'), $book->id) :  route('overview.book', $book->id) }}">{{$book->part}}</a>
                                </li>
                            @endforeach
                        </ul>
                    </div>
                </div>
        </div>
    </div>


</section>
<!-- end sectionTWO -->
<script src="{{asset('site/js/bootstrap.min.js')}}"></script>


</body>

</html>
