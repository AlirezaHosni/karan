<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BooksExercise extends Model
{
    protected $table = 'books_exercises';

    protected $fillable = ['title', 'book_id'];

    public function book()
    {
        return $this->belongsTo(book::class);
    }

    public function videos()
    {
        return $this->morphMany(Video::class, 'videoable');
    }

    public function documents()
    {
        return $this->morphMany(Document::class, 'documentable');
    }
}
