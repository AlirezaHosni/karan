<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GradeDescription extends Model
{
    protected $fillable = ['description', 'descriptionTwo', 'image', 'imageTwo', 'grade_id'];
    
    protected $table = 'grades_descriptions';
    
    public function grade()
    {
        return $this->belongsTo(Grade::class);
    }
}
