<?php

namespace App\Http\Controllers;

use App\Grade;
use App\User;
use App\GradeDescription;
use Illuminate\Http\Request;

class GradeController extends Controller
{

    public function index()
    {
        $grades=Grade::all();
       return view('backEnd.grade.index')->with(compact('grades'));
    }


    public function indexDescription()
    {
        $gradeDescriptions = GradeDescription::all();

        return view('backEnd.grade.index-description', compact('gradeDescriptions'));
    }

    public function createDescription()
    {
        $grades = Grade::all();
        $users = User::role('دبیر')->get();

        return view('backEnd.grade.create-description', compact('grades', 'users'));
    }
    
    public function storeDescription(Request $request)
    {
        $data['description'] = $request->description;
        $data['descriptionTwo'] = $request->descriptionTwo;
        $file=$request->file('image');
        if(!empty($file)){
            $image=$file->getClientOriginalName();
            $path="upload/grade/".$image;

            if (file_exists($path)){
                $image=bin2hex(random_bytes(4)).$image;
        }

        $file->move("upload/grade/",$image);
        $data['image']="upload/grade/".$image;
        };
        $file2=$request->file('imageTwo');
        if(!empty($file2)){
            $image=$file2->getClientOriginalName();
            $path="upload/grade/".$image;

            if (file_exists($path)){
                $image=bin2hex(random_bytes(4)).$image;
        }

        $file2->move("upload/grade/",$image);
        $data['imageTwo']="upload/grade/".$image;
        };
        $data['grade_id'] = $request->grade_id;
        GradeDescription::create($data);
        return redirect()->route('grade.index');
    }
    
    public function editDescription(GradeDescription $gradeDescriptions)
    {
        $grades = Grade::all();
        $users = User::role('دبیر')->get();

        return view('backEnd.grade.edit-description', compact('grades', 'users', 'gradeDescriptions'));
    }
    
    public function updateDescription(GradeDescription $gradeDescriptions, Request $request)
    {
        // $gradeDescriptions->description = $request->description;
        // $gradeDescriptions->descriptionTwo = $request->descriptionTwo;
        $data = $request->all();
        $file=$request->file('image');
        if(!empty($file)){
            $image=$file->getClientOriginalName();
            $path="upload/grade/".$image;

            if (file_exists($path)){
                $image=bin2hex(random_bytes(4)).$image;
        }

        $file->move("upload/grade/",$image);
        $data['image']="upload/grade/".$image;
        };
        $file2=$request->file('imageTwo');
        if(!empty($file2)){
            $image=$file2->getClientOriginalName();
            $path="upload/grade/".$image;

            if (file_exists($path)){
                $image=bin2hex(random_bytes(4)).$image;
        }

        $file2->move("upload/grade/",$image);
        $data['imageTwo']="upload/grade/".$image;
        };
        // $gradeDescriptions->grade_id = $request->grade_id;
        $gradeDescriptions->update($data);
        return redirect()->route('grade.index');
    }
    
    public function destroyDescription(GradeDescription $gradeDescriptions)
    {
        $gradeDescriptions->delete();

        return redirect()->back();
    }
    
    public function karanBala(Grade $grade)
    {
        // dd($grade->gradeDescription);
        $users = $grade->users;
        return view('frontEnd.grade.karanbala', compact('grade', 'users'));
    }

    
    public function create()
    {
        return view('backEnd.grade.create');
    }

    public function store(Request $request)
    {
        $grade=new Grade();
        $grade->title=$request->title;
        $grade->save();
        return redirect()->route('grade.index');
    }


    public function show(Grade $grade)
    {
        //
    }

    public function edit($grade)
    {
       $grade=Grade::findOrFail($grade);
       return view('backEnd.grade.edit')->with(compact('grade'));
    }

    public function update(Request $request,$grade)
    {
        $grade=Grade::findOrFail($grade);
        $grade->title=$request->title;
        $grade->save();
        return redirect()->route('grade.index');
    }

    public function destroy($grade)
    {
        Grade::destroy($grade);
        return redirect()->route('grade.index');

    }
}
