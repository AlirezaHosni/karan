<?php

namespace App\Http\Controllers;

use App\book;
use App\Grade;
use App\Lesson;
use App\Topic;
use Illuminate\Http\Request;

class BookController extends Controller
{

    public function index()
    {
        $books = book::whereNull('part')->get();
        $grades = Grade::all();
        $lesson = Lesson::all();
        return view('backEnd.book.index')->with(compact('books', 'grades', 'lesson'));
    }

    public function indexPart()
    {
        $books = book::whereNull('part')->get();
        $grades = Grade::all();
        $lesson = Lesson::all();
        $topics = Topic::all();
        return view('backEnd.book.index-part')->with(compact('books', 'grades', 'lesson', 'topics'));
    }

    public function create()
    {
        $grades=Grade::all();
        return view('backEnd.book.create')->with(compact('grades'));
    }

    public function store(Request $request)
    {
        $book=new book();
        $book->session=$request->session;
        $book->part=$request->part;
        $book->lesson_id=$request->lesson_id;
        $file=$request->file('image');
        if(!empty($file)){
            $image=$file->getClientOriginalName();
            $path="upload/book/".$image;

            if (file_exists($path)){
                $image=bin2hex(random_bytes(4)).$image;
        }

        $file->move("upload/book/",$image);
        $book->image ="upload/book/".$image;
        }
        $book->save();
        return  redirect()->route('book.index');
    }

    public function storePart(Request $request)
    {
        $book=new book();
        $book->session=$request->session;
        $book->part=$request->part;
        $book->lesson_id=$request->lesson_id;
        $file=$request->file('image');
        if(!empty($file)){
            $image=$file->getClientOriginalName();
            $path="upload/book/".$image;

            if (file_exists($path)){
                $image=bin2hex(random_bytes(4)).$image;
            }

            $file->move("upload/book/",$image);
            $book->image ="upload/book/".$image;
        }
        $book->save();
        for ($i=0;$i<count($request->topic);$i++) {
            Topic::create([
                'title' => $request->topic[$i],
                'book_id' => $book->id
            ]);
        }
        return  redirect()->route('book-part.index');
    }


    public function show($book)
    {
        $books=book::findOrFail($book);
        $exam=book::findOrFail($book)->examBooks()->get();
        return view('backEnd.book.showExam')->with(compact('exam','books'));

    }

    public function edit(book $book)
    {
        $lesson = Lesson::all();
        $grades = Grade::all();
        $books = book::distinct(['session', 'lesson_id'])->get();

        return view('backEnd.book.edit')->with(compact('lesson', 'book', 'grades', 'books'));
    }

    public function editPart(book $book)
    {
        $lesson = Lesson::all();
        $grades = Grade::all();
        $books = book::distinct(['session', 'lesson_id'])->get();
        $topics = Topic::all();

        return view('backEnd.book.edit-part')->with(compact('lesson', 'book', 'grades', 'books', 'topics'));
    }

    public function update(Request $request, book $book)
    {
        $books = book::where('session', 'like', "%$book->session%")->get();
        foreach($books as $item){
            $item->session = $request->session;
            $item->save();
        }
        $book->session=$request->session;
        $book->part=$request->part;
        $book->lesson_id=$request->lesson_id;
        $file=$request->file('image');
        if(!empty($file)){
            $image=$file->getClientOriginalName();
            $path="upload/book/".$image;

            if (file_exists($path)){
                $image=bin2hex(random_bytes(4)).$image;
            }

            if ($book->image)
                unlink($book->image);

            $file->move("upload/book/",$image);
            $book->image ="upload/book/".$image;
        }
        $book->save();
        return  redirect()->route('book.index');
    }

    public function updatePart(Request $request, book $book)
    {
        $book=new book();
        $book->session=$request->session;
        $book->part=$request->part;
        $book->lesson_id=$request->lesson_id;
        $file=$request->file('image');
        if(!empty($file)){
            $image=$file->getClientOriginalName();
            $path="upload/book/".$image;

            if (file_exists($path)){
                $image=bin2hex(random_bytes(4)).$image;
            }

            if ($book->image)
                unlink($book->image);

            $file->move("upload/book/",$image);
            $book->image ="upload/book/".$image;
        }
        $book->save();

        foreach ($book->topics as $topic){
            $topic->delete();
        }

        for ($i=0;$i<count($request->topic);$i++) {
            Topic::create([
                'title' => $request->topic[$i],
                'book_id' => $book->id
            ]);
        }
        return  redirect()->route('book-part.index');
    }

    public function destroy(book $book)
    {
        foreach ($book->topics as $topic){
            $topic->delete();
        }
        $book->delete();
        return redirect()->route('book.index');
    }

    public function destroyPart(Topic $topic)
    {
        $topic->delete();
        return redirect()->route('book-part.index');
    }

    public function search(Request $request){

          $lesson=Grade::findOrFail($request->id)->lessons()->get();
          return view('backEnd.book.create')->with(compact('lesson'));

    }
}
