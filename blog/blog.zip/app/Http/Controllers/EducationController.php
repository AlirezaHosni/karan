<?php

namespace App\Http\Controllers;

use App\Appendices;
use App\book;
use App\BooksExercise;
use App\DescriptiveTest;
use App\Document;
use App\ExamBook;
use App\ExamQuestionSample;
use App\Grade;
use App\Lesson;
use App\TextBook;
use App\Topic;
use App\Video;
use Illuminate\Http\Request;

class EducationController extends Controller
{
    public function textBookAttachmentsIndex()
    {
        $videos = Video::where('videoable_type', TextBook::class)->get();
        $documents = Document::where('documentable_type', TextBook::class)->get();
        $grades = Grade::all();
        return view('backEnd.education.attachments.textBook.index', compact('videos', 'documents', 'grades'));

    }

    public function textBookAttachmentsStore(Request $request)
    {
        for ($i=0;$i<count($request->file('attachments'));$i++){
            $topic = Topic::find($request->topic_id);
            if ($request->file('attachments.'.$i)->extension() == 'pdf'){
                $file = $request->file('attachments.'.$i);
                $filename = $file->getClientOriginalName();
                $path = 'upload/document/' . $filename;
                if (file_exists($path)){
                    $filename = bin2hex(random_bytes(4)).$filename;
                }
                $file->move('upload/document/', $filename);

                Document::create([
                    'documentable_type' => TextBook::class,
                    'documentable_id' => $topic->text_book->id,
                    'title' => $topic->title,
                    'document' => $path
                ]);
            }else{
                $file = $request->file('attachments.'.$i);
                $filename = $file->getClientOriginalName();
                $path = 'upload/video/' . $filename;
                if (file_exists($path)){
                    $filename = bin2hex(random_bytes(4)).$filename;
                }
                $file->move('upload/video/', $filename);

                Video::create([
                    'videoable_type' => TextBook::class,
                    'videoable_id' => $topic->text_book->id,
                    'title' => $topic->title,
                    'video' => $path
                ]);
            }
        }
        return redirect()->route('education.textBookAttachmentsIndex');
    }

    public function karanBalAttachmentsIndex()
    {
        $videos = Video::where('videoable_type', TextBook::class)->get();
        $documents = Document::where('documentable_type', TextBook::class)->get();
        $grades = Grade::all();
        return view('backEnd.education.attachments.karanbala.index', compact('videos', 'documents', 'grades'));
    }


    public function examBookAttachmentsIndex()
    {
        $videos = Video::where('videoable_type', ExamBook::class)->get();
        $documents = Document::where('documentable_type', ExamBook::class)->get();
        $grades = Grade::all();
        return view('backEnd.education.attachments.examBook.index', compact('videos', 'documents', 'grades'));
    }

    public function descriptiveTestAttachmentsIndex()
    {
        $videos = Video::where('videoable_type', DescriptiveTest::class)->get();
        $documents = Document::where('documentable_type', DescriptiveTest::class)->get();
        $grades = Grade::all();

        return view('backEnd.education.attachments.descriptiveTest.index', compact('videos', 'documents', 'grades'));
    }

    public function IntroduceBookAttachmentsIndex()
    {
        $videos = Video::where('videoable_type', Lesson::class)->get();
        $documents = Document::where('documentable_type', Lesson::class)->get();
        $grades = Grade::all();

        return view('backEnd.education.attachments.lesson.index', compact('videos', 'documents', 'grades'));
    }

    public function IntroduceBookAttachmentsStore(Request $request)
    {
        for ($i=0;$i<count($request->file('attachments'));$i++){
            $lesson = Lesson::find($request->lesson_id);

            if ($request->file('attachments.'.$i)->extension() == 'pdf'){
                $file = $request->file('attachments.'.$i);
                $filename = $file->getClientOriginalName();
                $path = 'upload/document/' . $filename;
                if (file_exists($path)){
                    $filename = bin2hex(random_bytes(4)).$filename;
                }
                $file->move('upload/document/', $filename);

                Document::create([
                    'documentable_type' => Lesson::class,
                    'documentable_id' => $lesson->id,
                    'title' => $lesson->title,
                    'document' => $path
                ]);
            }elseif(in_array(strtoupper($request->file('attachments.'.$i)->extension()), ['MP4', 'MOV', 'AVI', 'FLV', 'MKV', 'MKV', 'WMV', 'AVCHD', 'WEBM'])){
                $file = $request->file('attachments.'.$i);
                $filename = $file->getClientOriginalName();
                $path = 'upload/video/' . $filename;
                if (file_exists($path)){
                    $filename = bin2hex(random_bytes(4)).$filename;
                }
                $file->move('upload/video/', $filename);

                Video::create([
                    'videoable_type' => Lesson::class,
                    'videoable_id' => $lesson->id,
                    'title' => $lesson->title,
                    'video' => $path
                ]);
            }
        }
        return redirect()->route('education.IntroduceBookAttachmentsIndex');
    }

    public function booksExercisesAttachmentsIndex()
    {
        $videos = Video::where('videoable_type', BooksExercise::class)->get();
        $documents = Document::where('documentable_type', BooksExercise::class)->get();
        $grades = Grade::all();

        return view('backEnd.education.attachments.booksExercise.index', compact('videos', 'documents', 'grades'));
    }

    public function booksExercisesAttachmentsStore(Request $request)
    {
        for ($i=0;$i<count($request->file('attachments'));$i++){
            $book = book::find($request->session_id);
            $bookExercise = BooksExercise::create([
                'title' => $book->session,
                'book_id' => $book->id
            ]);

            if ($request->file('attachments.'.$i)->extension() == 'pdf'){
                $file = $request->file('attachments.'.$i);
                $filename = $file->getClientOriginalName();
                $path = 'upload/document/' . $filename;
                if (file_exists($path)){
                    $filename = bin2hex(random_bytes(4)).$filename;
                }
                $file->move('upload/document/', $filename);

                Document::create([
                    'documentable_type' => BooksExercise::class,
                    'documentable_id' => $bookExercise->id,
                    'title' => $bookExercise->title,
                    'document' => $path
                ]);
            }elseif(in_array(strtoupper($request->file('attachments.'.$i)->extension()), ['MP4', 'MOV', 'AVI', 'FLV', 'MKV', 'MKV', 'WMV', 'AVCHD', 'WEBM'])){
                $file = $request->file('attachments.'.$i);
                $filename = $file->getClientOriginalName();
                $path = 'upload/video/' . $filename;
                if (file_exists($path)){
                    $filename = bin2hex(random_bytes(4)).$filename;
                }
                $file->move('upload/video/', $filename);

                Video::create([
                    'videoable_type' => BooksExercise::class,
                    'videoable_id' => $bookExercise->id,
                    'title' => $bookExercise->title,
                    'video' => $path
                ]);
            }
        }
        return redirect()->route('education.booksExercisesAttachmentsIndex');
    }

    public function ExamQuestionSampleAttachmentsIndex()
    {
        $videos = Video::where('videoable_type', ExamQuestionSample::class)->get();
        $documents = Document::where('documentable_type', ExamQuestionSample::class)->get();
        $grades = Grade::all();

        return view('backEnd.education.attachments.examQuestionSample.index', compact('videos', 'documents', 'grades'));
    }

    public function ExamQuestionSampleAttachmentsStore(Request $request)
    {
        $lesson = Lesson::find($request->lesson_id);
        for ($i=0;$i<count($request->file('attachments'));$i++){
            $examBookSample = ExamQuestionSample::create([
                'title' => $lesson->title,
                'book_id' => $lesson->id,
                'type' => $request->type,
                'period' => $request->period,
            ]);

            if ($request->file('attachments.'.$i)->extension() == 'pdf'){
                $file = $request->file('attachments.'.$i);
                $filename = $file->getClientOriginalName();
                $path = 'upload/document/' . $filename;
                if (file_exists($path)){
                    $filename = bin2hex(random_bytes(4)).$filename;
                }
                $file->move('upload/document/', $filename);

                Document::create([
                    'documentable_type' => ExamQuestionSample::class,
                    'documentable_id' => $examBookSample->id,
                    'title' => $examBookSample->title,
                    'document' => $path
                ]);
            }elseif(in_array(strtoupper($request->file('attachments.'.$i)->extension()), ['MP4', 'MOV', 'AVI', 'FLV', 'MKV', 'MKV', 'WMV', 'AVCHD', 'WEBM'])){
                $file = $request->file('attachments.'.$i);
                $filename = $file->getClientOriginalName();
                $path = 'upload/video/' . $filename;
                if (file_exists($path)){
                    $filename = bin2hex(random_bytes(4)).$filename;
                }
                $file->move('upload/video/', $filename);

                Video::create([
                    'videoable_type' => ExamQuestionSample::class,
                    'videoable_id' => $examBookSample->id,
                    'title' => $examBookSample->title,
                    'video' => $path
                ]);
            }
        }
        return redirect()->route('education.ExamQuestionSampleAttachmentsIndex');
    }

    public function generalExamBookIndex()
    {
        $generalTests = ExamBook::where('exam_id', null)->get();
        $grades = Grade::all();

        return view('backEnd.education.examBook.index', compact('generalTests', 'grades'));
    }

    public function generalExamBookStore(Request $request)
    {
        for ($i=0;$i<count($request->question);$i++){
            $data = [
                'question'=>$request->question[$i],
                'answerOne'=>$request->answerOne[$i],
                'answerTwo'=>$request->answerTwo[$i],
                'answerThree'=>$request->answerThree[$i],
                'answerFour'=>$request->answerFour[$i],
                'True'=>$request->True[$i],
                'testable_type'=>book::class,
                'testable_id'=>$request->session_id,
            ];
            if($request->hasFile('audio.'.$i)){
                $file = $request->file('audio.'.$i);
                $filename = $file->getClientOriginalName();
                $path = 'upload/audio/' . $filename;
                if (file_exists($path)){
                    $filename = bin2hex(random_bytes(4)).$filename;
                }
                $file->move('upload/audio/examBook/', $filename);
                $data['audio'] = 'upload/audio/examBook/' .  $filename;
            }
            $file=$request->file('answerOneImage.'.$i);
            if(!empty($file)){
                $image=$file->getClientOriginalName();
                $path="upload/exam/".$image;

                if (file_exists($path)){
                    $image=bin2hex(random_bytes(4)).$image;
                }

                $file->move("upload/exam/",$image);
                $data['imageOne'] = "upload/exam/" . $image;
            }
            $file=$request->file('answerTwoImage.'.$i);
            if(!empty($file)){
                $image=$file->getClientOriginalName();
                $path="upload/exam/".$image;

                if (file_exists($path)){
                    $image=bin2hex(random_bytes(4)).$image;
                }

                $file->move("upload/exam/",$image);
                $data['imageTwo'] = "upload/exam/" . $image;
            }
            $file=$request->file('answerThreeImage.'.$i);
            if(!empty($file)){
                $image=$file->getClientOriginalName();
                $path="upload/exam/".$image;

                if (file_exists($path)){
                    $image=bin2hex(random_bytes(4)).$image;
                }

                $file->move("upload/exam/",$image);
                $data['imageThree'] = "upload/exam/" . $image;
            }
            $file=$request->file('answerFourImage.'.$i);
            if(!empty($file)){
                $image=$file->getClientOriginalName();
                $path="upload/exam/".$image;

                if (file_exists($path)){
                    $image=bin2hex(random_bytes(4)).$image;
                }

                $file->move("upload/exam/",$image);
                $data['imageFour'] = "upload/exam/" . $image;
            }
            $parentExamBook = ExamBook::create($data);

            for ($j=0;$j<count($request->input("question_$i"));$j++){
                if (isset($request->input("question_$i")[$j])){
                    $childData = [
                        'question'=>$request->input("question_$i")[$j],
                        'answerOne'=>$request->input("answerOne_$i")[$j],
                        'answerTwo'=>$request->input("answerTwo_$i")[$j],
                        'answerThree'=>$request->input("answerThree_$i")[$j],
                        'answerFour'=>$request->input("answerFour_$i")[$j],
                        'True'=>$request->input("True_$i")[$j],
                        'testable_type'=>book::class,
                        'testable_id'=>$request->session_id,
                        'parent_id' => $parentExamBook->id
                    ];
                    $file=$request->file("answerOneImage_$i.".$j);
                    if(!empty($file)){
                        $image=$file->getClientOriginalName();
                        $path="upload/exam/".$image;

                        if (file_exists($path)){
                            $image=bin2hex(random_bytes(4)).$image;
                        }

                        $file->move("upload/exam/",$image);
                        $childData['imageOne'] = "upload/exam/" . $image;
                    }
                    $file=$request->file("answerTwoImage_$i.".$j);
                    if(!empty($file)){
                        $image=$file->getClientOriginalName();
                        $path="upload/exam/".$image;

                        if (file_exists($path)){
                            $image=bin2hex(random_bytes(4)).$image;
                        }

                        $file->move("upload/exam/",$image);
                        $childData['imageTwo'] = "upload/exam/" . $image;
                    }
                    $file=$request->file("answerThreeImage_$i.".$j);
                    if(!empty($file)){
                        $image=$file->getClientOriginalName();
                        $path="upload/exam/".$image;

                        if (file_exists($path)){
                            $image=bin2hex(random_bytes(4)).$image;
                        }

                        $file->move("upload/exam/",$image);
                        $childData['imageThree'] = "upload/exam/" . $image;
                    }
                    $file=$request->file("answerFourImage_$i.".$j);
                    if(!empty($file)){
                        $image=$file->getClientOriginalName();
                        $path="upload/exam/".$image;

                        if (file_exists($path)){
                            $image=bin2hex(random_bytes(4)).$image;
                        }

                        $file->move("upload/exam/",$image);
                        $childData['imageFour'] = "upload/exam/" . $image;
                    }
                    ExamBook::create($childData);
                }
            }
        }

        return redirect()->route('education.generalExamBookIndex');
    }

    public function AppendicesAttachmentsIndex($type=null)
    {
        if ($type != null){
            $videos = Video::whereHasMorph('videoable', Appendices::class, function ($query) use ($type) {
                $query->where('type', $type);
            })->get();
            $documents = Document::whereHasMorph('documentable', Appendices::class, function ($query) use ($type) {
                $query->where('type', $type);
            })->get();
        }
        else{
            $videos = Video::where('videoable_type', Appendices::class)->get();
            $documents = Document::where('documentable_type', Appendices::class)->get();
        }
        $grades = Grade::all();

        return view('backEnd.education.attachments.appendices.index', compact('videos', 'documents', 'grades'));
    }

    public function AppendicesAttachmentsStore(Request $request)
    {
        for ($i=0;$i<count($request->file('attachments'));$i++){
            $book = book::find($request->session_id);
            $appendices = Appendices::create([
                'title' => $book->session,
                'type' => $request->input('type'.$i, 0),
                'book_id' => $book->id
            ]);

            if ($request->file('attachments.'.$i)->extension() == 'pdf'){
                $file = $request->file('attachments.'.$i);
                $filename = $file->getClientOriginalName();
                $path = 'upload/document/' . $filename;
                if (file_exists($path)){
                    $filename = bin2hex(random_bytes(4)).$filename;
                }
                $file->move('upload/document/', $filename);

                Document::create([
                    'documentable_type' => Appendices::class,
                    'documentable_id' => $appendices->id,
                    'title' => $appendices->title,
                    'document' => $path
                ]);
            }elseif(in_array(strtoupper($request->file('attachments.'.$i)->extension()), ['MP4', 'MOV', 'AVI', 'FLV', 'MKV', 'MKV', 'WMV', 'AVCHD', 'WEBM'])){
                $file = $request->file('attachments.'.$i);
                $filename = $file->getClientOriginalName();
                $path = 'upload/video/' . $filename;
                if (file_exists($path)){
                    $filename = bin2hex(random_bytes(4)).$filename;
                }
                $file->move('upload/video/', $filename);

                Video::create([
                    'videoable_type' => Appendices::class,
                    'videoable_id' => $appendices->id,
                    'title' => $appendices->title,
                    'video' => $path
                ]);
            }
        }
        return redirect()->route('education.AppendicesAttachmentsStore');
    }
}
