<?php

namespace App\Http\Controllers;

use App\book;
use App\Lesson;
use App\Topic;
use Illuminate\Http\Request;

class HomeController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        return view('backEnd.home');
    }

    public function searchLessons(Request $request)
    {
        if (!empty($request->grade_id))
            return response()->json(Lesson::where('grade_id', $request->grade_id)->get());
    }

    public function searchSessions(Request $request)
    {
        if (!empty($request->lesson_id))
            return response()->json(book::where('lesson_id', $request->lesson_id)->where('part', null)->get());
    }

    public function searchParts(Request $request)
    {
        if (!empty($request->session_id)){
            $session = book::find($request->session_id);
            return response()->json(book::where('session', 'like', "%$session->session%")->whereNotNull('part')->get());
        }
    }

    public function searchTopics(Request $request)
    {
        if (!empty($request->part_id))
            return response()->json(Topic::where('book_id', $request->part_id)->get());
    }
}
