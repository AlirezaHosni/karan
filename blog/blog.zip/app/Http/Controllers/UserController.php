<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use App\User;
use Illuminate\Http\Request;

class UserController extends Controller
{

    public function index()
    {
        $users=User::all();
        return view('backEnd.usermanagement.index')->with(compact('users'));
    }

    public function create()
    {

    }

    public function store(Request $request)
    {



    }

    public function show($id)
    {
        //
    }

    public function edit($id)
    {
        $roles=Role::all();
        $user=User::findOrFail($id);
        return view('backEnd.usermanagement.edit')->with(compact('user','roles'));

    }

    public function update(Request $request, $id)
    {
        $user=User::findOrFail($id);
        $user->name=$request->name;
        $user->fullName=$request->fullName;
        $user->email=$request->email;
        $user->phoneNumber=$request->phoneNumber;
        $user->save();
        $user->syncRoles($request->role_id);
        return redirect()->route('userManagement.index');

    }

    public function destroy($id)
    {
        $user=User::findOrFail($id);
        $image=$user->image;
        if (!empty($image)){
            $path="upload/user/".$image;
            unlink($path);
        }
        User::destroy($user->id);
        return redirect()->back();
    }
    public function UploadImage(Request $request,$id){
       $user=User::findOrFail($id);
        $file=$request->file('image');
        if (empty($file)){
            $image=$user->image;
            $user->image=$image;
        }else{
            $oldImage=$user->image;
            if (!empty($oldImage)){
                $oldPath="upload/user/".$oldImage;
                unlink($oldPath);
            }
            $image=$file->getClientOriginalName();
            $path="upload/user/".$image;
            if (file_exists($path)){
                $image=bin2hex(random_bytes(5)).$image;
            }
            $file->move("upload/user/",$image);
            $user->image=$image;
        }
        $user->save();
        return redirect()->back();
    }
}
