<?php

namespace App\Http\Controllers;

use App\book;
use App\DescriptiveTest;
use App\Document;
use App\ExamBook;
use App\Grade;
use App\Lesson;
use App\TextBook;
use App\Video;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class SiteController extends Controller
{
    public function grades()
    {
        $grades = Grade::all();
        return view('site.grade', compact('grades'));
    }

    public function lessons($gradeid)
    {
        $lessons = Lesson::where('grade_id', '=', $gradeid)->get();
        return view('site.lesson', compact('lessons'));

    }

    public function book(book $book)
    {
        $books = book::where('session', 'like', "%$book->session%")->orderby('id', 'asc')->get();
        return view('site.book', compact('books'));
    }

    public function sessionBook($lessonid, $operation)
    {
        if ($operation){
            Session::put('operation', $operation);
        }
        $books = book::where('lesson_id', '=', $lessonid)->distinct('session')->get();
        // dd($books);
        return view('site.session-book', compact('books'));
    }

    public function introduceBook(book $book)
    {
        return view('site.introduce-book', compact('book'));
    }


    public function overviewBook(book $book)
    {
        $videos = Video::where('type', 1)->whereHasMorph('videoable', book::class, function ($query) use ($book){
            return $query->where('id', $book->id);
        })->get();
        $documents = Document::where('type', 1)->whereHasMorph('documentable', book::class, function ($query) use ($book){
            return $query->where('id', $book->id);
        })->get();
        $operation = 'book';

        return view('site.overview', compact('book', 'videos', 'documents', 'operation'));
    }

    public function textBook(book $book)
    {
        $videos = Video::where('type', 4)->whereHasMorph('videoable', TextBook::class, function ($query) use ($book){
            return $query->where('book_id', $book->id);
        })->get();
        $documents = Document::where('type', 4)->whereHasMorph('documentable', TextBook::class, function ($query) use ($book){
            return $query->where('book_id', $book->id);
        })->get();
        $operation = 'textBook';

        return view('site.overview', compact('book', 'videos', 'documents', 'operation'));

    }

    public function descriptive(book $book)
    {
        $videos = Video::where('type', 2)->whereHasMorph('videoable', DescriptiveTest::class, function ($query) use ($book){
            return $query->where('book_id', $book->id);
        })->get();
        $documents = Document::where('type', 2)->whereHasMorph('documentable', DescriptiveTest::class, function ($query) use ($book){
            return $query->where('book_id', $book->id);
        })->get();
        $operation = 'descriptive';

        return view('site.overview', compact('book', 'videos', 'documents', 'operation'));
    }

    public function testExam(book $book)
    {
        $videos = Video::where('type', 3)->whereHasMorph('videoable', ExamBook::class, function ($query) use ($book){
            return $query->where('book_id', $book->id);
        })->get();
        $documents = Document::where('type', 3)->whereHasMorph('documentable', ExamBook::class, function ($query) use ($book){
            return $query->where('book_id', $book->id);
        })->get();
        $operation = 'testExam';

        return view('site.overview', compact('book', 'videos', 'documents', 'operation'));
    }

    public function appendices(book $book)
    {
        $videos = Video::where('type', 1)->whereHasMorph('videoable', book::class, function ($query) use ($book){
            return $query->where('id', $book->id);
        })->get();
        $documents = Document::where('type', 1)->whereHasMorph('documentable', book::class, function ($query) use ($book){
            return $query->where('id', $book->id);
        })->get();
        $operation = 'appendices';

        return view('site.overview', compact('book', 'videos', 'documents', 'operation'));
    }

//    public function test(book $book)
//    {
//        $videos = Video::where('type', 1)->where('book_id', $book->id)->get();
//        $documents = Document::where('type', 1)->where('book_id', $book->id)->get();
//
//                return view('site.overview', compact('book', 'videos', 'documents', 'operation'));

//    }

    public function booksPractices(book $book)
    {
        $videos = Video::where('type', 1)->whereHasMorph('videoable', book::class, function ($query) use ($book){
            return $query->where('id', $book->id);
        })->get();
        $documents = Document::where('type', 1)->whereHasMorph('documentable', book::class, function ($query) use ($book){
            return $query->where('id', $book->id);
        })->get();
        $operation = 'booksPractices';

        return view('site.overview', compact('book', 'videos', 'documents', 'operation'));

    }

    public function examsQuestions(book $book)
    {
        $videos = Video::where('type', 1)->whereHasMorph('videoable', book::class, function ($query) use ($book){
            return $query->where('id', $book->id);
        })->get();
        $documents = Document::where('type', 1)->whereHasMorph('documentable', book::class, function ($query) use ($book){
            return $query->where('id', $book->id);
        })->get();
        $operation = 'examsQuestions';

        return view('site.overview', compact('book', 'videos', 'documents', 'operation'));

    }

    public function generalTest(book $book)
    {
        $videos = Video::where('type', 1)->whereHasMorph('videoable', book::class, function ($query) use ($book){
            return $query->where('id', $book->id);
        })->get();
        $documents = Document::where('type', 1)->whereHasMorph('documentable', book::class, function ($query) use ($book){
            return $query->where('id', $book->id);
        })->get();
        $operation = 'generalTest';

        return view('site.overview', compact('book', 'videos', 'documents', 'operation'));
    }

    public function onlineContact()
    {
        return 'online contact view';
    }

    public function exam($bookid)
    {
        return view('site.exam', compact('bookid'));
    }

    public function exam_view($bookid, Request $request)
    {
        if (isset($bookid)) {
            if ($request->type == 'test') {
                $examBook = ExamBook::where('book_id', '=', $bookid)->where('level', '=', $request->level)->get();
                $level = $request->level;
                $type = $request->type;
                return view('site.exam', compact('bookid', 'examBook', 'level'));
            }
            if ($request->type == 'tashrih') {
                abort(404);
            }
        }
    }
}
