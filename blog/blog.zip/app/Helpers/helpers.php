<?php

use Morilog\Jalali\Jalalian;

function jalaliDate($date, $format='%Y %m %d')
{
    return Jalalian::forge($date)->format($format);
}
