<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserDescription extends Model
{
    protected $guarded = ['id'];

    protected $table = 'user_descriptions';

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
