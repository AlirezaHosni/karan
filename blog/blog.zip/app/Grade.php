<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Grade extends Model
{
    protected $guarded=['id'];
    
    public function lessons(){
        return $this->hasMany(Lesson::class);
    }
    
    public function users(){
        return $this->belongsToMany(User::class, 'user_grade', 'grade_id', 'user_id');
    }
    
    public function gradeDescription(){
        return $this->hasOne(GradeDescription::class);
    }
}
