<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExamQuestionSample extends Model
{
    protected $table = 'exam_question_samples';

    protected $fillable = ['title', 'lesson_id', 'type', 'period'];

    public function book()
    {
        return $this->belongsTo(book::class);
    }

    public function videos()
    {
        return $this->morphMany(Video::class, 'videoable');
    }

    public function documents()
    {
        return $this->morphMany(Document::class, 'documentable');
    }
}
