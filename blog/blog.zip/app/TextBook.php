<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TextBook extends Model
{
    protected $fillable = ['title', 'book_id', 'body', 'image'];

    protected $table = 'textbooks';

    public function videos()
    {
        return $this->morphMany(Video::class, 'videoable');
    }

    public function documents()
    {
        return $this->morphMany(Document::class, 'documentable');
    }

    public function topic()
    {
        return $this->belongsTo(Topic::class);
    }
}
