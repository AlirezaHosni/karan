<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class book extends Model
{
    protected $guarded=['id'];

    public function lesson(){
        return $this->belongsTo(Lesson::class);
    }

    public function examBooks(){
        return $this->hasMany(ExamBook::class);
    }

    public function DescriptiveTests(){
        return $this->hasMany(DescriptiveTest::class);
    }

    public function videos()
    {
        return $this->morphMany(Video::class, 'videoable');
    }

    public function documents()
    {
        return $this->morphMany(Document::class, 'documentable');
    }

    public function getTitleAttribute()
    {
        return $this->session . '-' . $this->part;
    }

    public function topics()
    {
        return $this->hasMany(Topic::class);
    }

    public function appendices()
    {
        return $this->hasMany(Appendices::class);
    }

    public function tests()
    {
        return $this->morphMany(ExamBook::class, 'testable');
    }

}
